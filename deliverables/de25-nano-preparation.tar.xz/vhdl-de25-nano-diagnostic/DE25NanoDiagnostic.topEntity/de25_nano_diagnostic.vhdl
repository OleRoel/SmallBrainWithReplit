-- Automatically generated VHDL-93
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.MATH_REAL.ALL;
use std.textio.all;
use work.all;
use work.de25_nano_diagnostic_types.all;

entity de25_nano_diagnostic is
  port(-- clock
       CLOCK1_50 : in de25_nano_diagnostic_types.clk_Board50;
       KEY0      : in boolean;
       SW        : in std_logic_vector(3 downto 0);
       LEDR      : out std_logic_vector(7 downto 0));
end;

architecture structural of de25_nano_diagnostic is
  signal count                      : de25_nano_diagnostic_types.index_25000000;
  signal \on\                       : boolean;
  signal \c$case_alt\               : de25_nano_diagnostic_types.Tuple2;
  signal \c$app_arg\                : boolean := true;
  signal \c$app_arg_0\              : boolean := true;
  signal rst                        : de25_nano_diagnostic_types.rst_Board50;
  signal result                     : boolean := true;
  signal \c$app_arg_1\              : boolean := true;
  signal result_0                   : de25_nano_diagnostic_types.rst_Board50;
  signal \c$app_arg_2\              : std_logic_vector(3 downto 0) := std_logic_vector'(x"0");
  signal \c$app_arg_3\              : std_logic_vector(3 downto 0) := std_logic_vector'(x"0");
  signal \c$app_arg_4\              : std_logic_vector(0 downto 0);
  signal \c$app_arg_5\              : std_logic_vector(0 downto 0);
  signal \c$app_arg_6\              : std_logic_vector(0 downto 0);
  signal rst_0                      : de25_nano_diagnostic_types.rst_Board50;
  signal counter                    : de25_nano_diagnostic_types.Tuple2 := (Tuple2_sel0_index_25000000 => to_unsigned(0,25), Tuple2_sel1_boolean => false);
  signal \c$case_alt_selection_res\ : boolean;
  signal \c$app_arg_selection_res\  : boolean;
  signal \c$app_arg_selection_3\    : boolean;

begin
  count <= counter.Tuple2_sel0_index_25000000;

  \on\ <= counter.Tuple2_sel1_boolean;

  \c$case_alt_selection_res\ <= count = to_unsigned(24999999,25);

  \c$case_alt\ <= ( Tuple2_sel0_index_25000000 => to_unsigned(0,25)
                  , Tuple2_sel1_boolean => not \on\ ) when \c$case_alt_selection_res\ else
                  ( Tuple2_sel0_index_25000000 => count + to_unsigned(1,25)
                  , Tuple2_sel1_boolean => \on\ );

  -- register begin
  capp_arg_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst_0 =  '1'  then
        \c$app_arg\ <= true;
      else
        \c$app_arg\ <= KEY0;
      end if;
    end if;
  end process;
  -- register end

  -- register begin
  capp_arg_0_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst_0 =  '1'  then
        \c$app_arg_0\ <= true;
      else
        \c$app_arg_0\ <= \c$app_arg\;
      end if;
    end if;
  end process;
  -- register end

  rst <= '1' when false = true else '0';

  -- register begin
  result_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst =  '1'  then
        result <= true;
      else
        result <= \c$app_arg_1\;
      end if;
    end if;
  end process;
  -- register end

  -- register begin
  capp_arg_1_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst =  '1'  then
        \c$app_arg_1\ <= true;
      else
        \c$app_arg_1\ <= (not KEY0);
      end if;
    end if;
  end process;
  -- register end

  result_0 <= '1' when result = true else '0';

  -- register begin
  capp_arg_2_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst_0 =  '1'  then
        \c$app_arg_2\ <= std_logic_vector'(x"0");
      else
        \c$app_arg_2\ <= SW;
      end if;
    end if;
  end process;
  -- register end

  -- register begin
  capp_arg_3_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst_0 =  '1'  then
        \c$app_arg_3\ <= std_logic_vector'(x"0");
      else
        \c$app_arg_3\ <= \c$app_arg_2\;
      end if;
    end if;
  end process;
  -- register end

  \c$app_arg_4\ <= std_logic_vector'("1") when \c$app_arg_0\ else
                   std_logic_vector'("0");

  \c$app_arg_selection_res\ <= true when result_0 = '1' else false;

  \c$app_arg_5\ <= std_logic_vector'("1") when \c$app_arg_selection_res\ else
                   std_logic_vector'("0");

  \c$app_arg_selection_3\ <= counter.Tuple2_sel1_boolean;

  \c$app_arg_6\ <= std_logic_vector'("1") when \c$app_arg_selection_3\ else
                   std_logic_vector'("0");

  LEDR <= std_logic_vector'(std_logic_vector'((std_logic_vector'(std_logic_vector'((std_logic_vector'(std_logic_vector'((std_logic_vector'(std_logic_vector'(std_logic_vector'("1")) & std_logic_vector'((std_logic_vector'((\c$app_arg_6\))))))) & std_logic_vector'((std_logic_vector'((\c$app_arg_5\))))))) & std_logic_vector'((std_logic_vector'((\c$app_arg_4\))))))) & std_logic_vector'(\c$app_arg_3\));

  rst_0 <= '1' when false = true else '0';

  -- register begin
  counter_register : process(CLOCK1_50)
  begin
    if rising_edge(CLOCK1_50) then
      if rst_0 =  '1'  then
        counter <= (Tuple2_sel0_index_25000000 => to_unsigned(0,25), Tuple2_sel1_boolean => false);
      else
        counter <= \c$case_alt\;
      end if;
    end if;
  end process;
  -- register end


end;

