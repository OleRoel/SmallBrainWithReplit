create_clock -name {CLOCK1_50} -period 20.000 -waveform {0.000 10.000} [get_ports {CLOCK1_50}]

