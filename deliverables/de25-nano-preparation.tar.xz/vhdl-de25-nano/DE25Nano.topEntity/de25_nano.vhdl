-- Automatically generated VHDL-93
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.MATH_REAL.ALL;
use std.textio.all;
use work.all;
use work.de25_nano_types.all;
library de1_soc;

entity de25_nano is
  port(-- clock
       CLOCK1_50 : in de25_nano_types.clk_Board50;
       KEY0      : in boolean;
       SW        : in std_logic_vector(3 downto 0);
       LEDR      : out std_logic_vector(7 downto 0));
end;

architecture structural of de25_nano is
  signal eta2     : std_logic_vector(9 downto 0);
  signal CLOCK_51 : de25_nano_types.clk_Board50;
  signal KEY0_0   : boolean;
  signal SW_0     : std_logic_vector(3 downto 0);
  signal LEDR_1   : std_logic_vector(9 downto 0);
  signal \c$bv\   : std_logic_vector(9 downto 0);

begin
  CLOCK_51 <= CLOCK1_50;

  KEY0_0 <= KEY0;

  SW_0 <= SW;

  de1_soc_eta2 : entity de1_soc.de1_soc
    port map
      (CLOCK_51, KEY0_0, SW_0, LEDR_1);

  eta2 <= LEDR_1;

  \c$bv\ <= (eta2);

  LEDR <= \c$bv\(7 downto 0);


end;

